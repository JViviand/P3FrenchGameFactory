//
//  Test des fonctions.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 02/11/2020.
//

import Foundation

/*func Attaquer
 
let nouvelleArmes1 = Armes(nom: "epee", dommage: 10)
let Perso1 = Personnage(nom: "jeremy", pointDevie: 100, type: nouvelleArmes1)

let nouvelleArmes2 = Armes(nom: "fourchette", dommage: 30)
let Perso2 = Personnage(nom: "victo", pointDevie: 100, type: nouvelleArmes2)

print("point de vie du personnage 2 avant attaque: \(Perso2.pointDevie)")
Perso1.Attaquer(Personnage: Perso2)
print("point de vie du personnage 2 apres attaque: \(Perso2.pointDevie)")*/


