//
//  Sword.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 22/11/2020.
//

import Foundation

// Sword herite de la class Weapon

class Sword: Weapon {
    init() {
        super.init(name: "Sword", damage: 25)
    }
}
