//
//  Hâche.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 11/10/2020.
//

import Foundation

class Hâche : Arme {
    init(){
        super.init (nom: "Hâche",dommage: 15)
    }
}
