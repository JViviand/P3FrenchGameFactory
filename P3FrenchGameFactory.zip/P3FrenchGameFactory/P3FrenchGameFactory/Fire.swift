//
//  Fire.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 11/10/2020.
//

import Foundation

// fire herite de la class Weapon

class Fire: Weapon {
    init() {
        super.init(name: "Fire", damage: 30)
    }
}
