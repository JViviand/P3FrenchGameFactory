//
//  Couteau.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 11/10/2020.
//

import Foundation

class Couteau : Arme {
    init(){
        super.init (nom: "Couteau",dommage: 10)
    }
}
