//
//  main.swift
//  FrenchGameFactory2
//
//  Created by Jeremy viviand on 31/10/2020.
//

import Foundation


print("Bienvenue dans un jeu de combat ou vous aller devoir choisir 3 personnage pour combattre : le dragon, l'elf ou le nain et gagner la partie !! attention dans le combat vous aller pouvoir tomber sur une boites mystere avec une nouvelles arme plus ou moin puissante, pret à combattre ?")


let test = Game()

test.start()

