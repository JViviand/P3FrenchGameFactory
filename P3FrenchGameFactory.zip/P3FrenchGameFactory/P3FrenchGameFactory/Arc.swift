//
//  Arc.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 22/11/2020.
//

import Foundation

// Arc herite de la class Weapon

class Arc: Weapon {
    init() {
        super.init(name: "Arc", damage: 20)
    }
}
