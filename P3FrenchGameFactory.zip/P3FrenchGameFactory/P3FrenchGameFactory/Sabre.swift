//
//  Sabre.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 11/10/2020.
//

import Foundation

class Sabre : Arme {
    init(){
        super.init (nom: "Sabre",dommage: 30)
    }
}
