//
//  Battes de Baseball.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 11/10/2020.
//

import Foundation

class Bâton : Arme {
    init(){
        super.init (nom: "Bâton", dommage: 5)
    }
    
}
