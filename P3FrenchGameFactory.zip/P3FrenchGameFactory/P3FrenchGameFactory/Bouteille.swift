//
//  Bouteille.swift
//  P3FrenchGameFactory
//
//  Created by Jeremy viviand on 11/10/2020.
//

import Foundation

class Bouteille : Arme {
    init(){
        super.init (nom: "Bouteille",dommage: 5)
    }
}
